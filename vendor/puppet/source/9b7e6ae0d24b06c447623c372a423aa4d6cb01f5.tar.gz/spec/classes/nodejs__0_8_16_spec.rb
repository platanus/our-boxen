require "spec_helper"

describe "nodejs::0_8_16" do
  let(:facts) { default_test_facts }

  it do
    should contain_nodejs__version("0.8.16")
  end
end
