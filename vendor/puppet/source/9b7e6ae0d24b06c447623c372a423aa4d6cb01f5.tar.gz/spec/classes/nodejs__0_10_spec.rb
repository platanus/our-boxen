require "spec_helper"

describe "nodejs::0_10" do
  let(:facts) { default_test_facts }

  it do
    should include_class("nodejs::0_10_26")

    should contain_file("/test/boxen/nodenv/versions/0.10").with({
      :ensure => "link",
      :target => "/test/boxen/nodenv/versions/0.10.26"
    })
  end
end
