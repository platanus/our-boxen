require "spec_helper"

describe "nodejs::0_8_19" do
  let(:facts) { default_test_facts }

  it do
    should contain_nodejs__version("0.8.19")
  end
end
