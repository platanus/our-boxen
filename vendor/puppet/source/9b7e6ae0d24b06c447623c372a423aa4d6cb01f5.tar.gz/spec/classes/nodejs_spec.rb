require "spec_helper"

describe "nodejs" do
  let(:facts) { default_test_facts }

  let(:root) { "/test/boxen/nodenv" }
  let(:versions) { "#{root}/versions" }

  it do
    should include_class("nodejs::rehash")
    should include_class("nodejs::nvm")

    should contain_repository(root).with({
      :ensure => "42420a8fa9b17b137b5809943bb481b49be8e8d4",
      :force  => true,
      :source => "OiNutter/nodenv",
      :user   => "testuser"
    })

    should contain_file(versions).with_ensure("directory")

    should contain_file("/test/boxen/env.d/nodenv.sh").with_ensure("absent")
    should contain_boxen__env_script("nodejs").with_source("puppet:///modules/nodejs/nodenv.sh")
  end

  context "Linux" do
    let(:facts) { default_test_facts.merge(:osfamily => "Linux") }

    it do
      should_not contain_boxen__env_script("nodejs")
    end
  end
end
