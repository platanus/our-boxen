require "spec_helper"

describe "nodejs::0_10_11" do
  let(:facts) { default_test_facts }

  it do
    should contain_nodejs__version("0.10.11")
  end
end
