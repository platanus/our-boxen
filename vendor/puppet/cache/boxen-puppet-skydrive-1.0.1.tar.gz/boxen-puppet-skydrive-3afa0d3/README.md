# SkyDrive Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-skydrive.png)](https://travis-ci.org/boxen/puppet-skydrive)

Install [SkyDrive](http://skydrive.live.com), an easy way to share files the MS way
on Mac OS X.

## Usage

```puppet
include skydrive
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
