# ImageMagick Puppet Module for Boxen

## Usage

```puppet
include imagemagick
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
* xquartz
