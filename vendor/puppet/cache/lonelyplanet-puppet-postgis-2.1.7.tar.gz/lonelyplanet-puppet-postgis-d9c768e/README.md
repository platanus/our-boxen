# Postgis Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include postgis
```

## Required Puppet Modules

* boxen
* homebrew