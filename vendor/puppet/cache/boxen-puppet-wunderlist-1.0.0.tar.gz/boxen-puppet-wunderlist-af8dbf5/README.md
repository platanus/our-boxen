# Wunderlist Puppet Module for Boxen

Install [Wunderlist](https://www.wunderlist.com) on your Mac.

## Usage

```puppet
include wunderlist
```

## Required Puppet Modules

* `boxen`
