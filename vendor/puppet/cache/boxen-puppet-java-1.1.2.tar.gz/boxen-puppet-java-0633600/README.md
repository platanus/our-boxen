# Java Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-java.png?branch=master)](https://travis-ci.org/boxen/puppet-java)

Installs Java 7u21.

## Usage

```puppet
include java
```

## Required Puppet Modules

None.
