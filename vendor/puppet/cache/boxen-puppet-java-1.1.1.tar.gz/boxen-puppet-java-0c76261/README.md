# Java Puppet Module for Boxen

Installs Java 7u21.

## Usage

```puppet
include java
```

## Required Puppet Modules

None.
