# Mumble Puppet Module for Boxen

Install [Mumble](http://mumble.sourceforge.net/), an open source voice chat software.

## Usage

```puppet
include mumble
```

## Required Puppet Modules

None.