require "spec_helper"

describe "nodejs::module" do
  let(:facts) { default_test_facts }
  let(:title) { "bower for 0.10" }
  let(:params) do
    { :node_version => "0.10", :module => "bower" }
  end

  it do
    should contain_nodejs__version("0.10")

    should contain_npm_module("bower for 0.10").with({
      :ensure       => "installed",
      :module       => "bower",
      :node_version => "0.10",
      :nodenv_root  => "/test/boxen/nodenv",
      :user         => "testuser",
      :provider     => "nodenv"
    })
  end
end
