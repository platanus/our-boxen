# SkyDrive Puppet Module for Boxen

Install [SkyDrive](http://skydrive.live.com), an easy way to share files the MS way
on Mac OS X.

## Usage

```puppet
include skydrive
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
