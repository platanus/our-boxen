require 'spec_helper'

describe 'googledrive' do
  it do
    should contain_package('GoogleDrive').with({
      :provider => 'pkg',
      :source   => 'https://dl.google.com/drive/installgoogledrive.dmg',
    })
  end
end
