# GoogleDrive Puppet Module for Boxen

Install [GoogleDrive](http://www.googledrive.com), for time tracking.

## Usage

```puppet
include googledrivee
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.