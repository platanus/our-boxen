# Sequel Pro Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-sequel_pro.png)](https://travis-ci.org/boxen/puppet-sequel_pro)

## Usage

```puppet
include sequel_pro
```

## Required Puppet Modules

`boxen`

## Developing

Write code.

Run `script/cibuild`.
